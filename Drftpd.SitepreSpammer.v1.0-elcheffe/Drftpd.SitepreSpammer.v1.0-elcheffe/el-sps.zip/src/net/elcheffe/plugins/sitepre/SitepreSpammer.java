package net.elcheffe.plugins.sitepre;

import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import net.sf.drftpd.ObjectNotFoundException;
import net.sf.drftpd.event.DirectoryFtpEvent;
import net.sf.drftpd.event.Event;
import net.sf.drftpd.event.FtpListener;
import net.sf.drftpd.event.TransferEvent;
import org.drftpd.SFVFile;
import org.drftpd.SFVFile.SFVStatus;
import org.drftpd.plugins.SiteBot;
import org.drftpd.remotefile.LinkedRemoteFile;
import org.drftpd.remotefile.LinkedRemoteFileInterface;
import org.drftpd.remotefile.LinkedRemoteFileUtils;

/**
 * @author elcheffe
 * @version 1.0
 * @since 2009-05-18
 */
public class SitepreSpammer extends FtpListener {
	private static final String channel = "#blabla.sitepre";
	private static final DecimalFormat PREFORMAT;
	
	static {
		DecimalFormatSymbols formatsymbols = new DecimalFormatSymbols();
		formatsymbols.setDecimalSeparator('.');
		PREFORMAT = new DecimalFormat("0.000", formatsymbols);
		PREFORMAT.setDecimalSeparatorAlwaysShown(true);
	}
	
	public SitepreSpammer() {
	}

	public void actionPerformed(Event event) {
		if ("RELOAD".equals(event.getCommand())) {
			return;
		} else if (event instanceof DirectoryFtpEvent) {
			actionPerformedDirectory((DirectoryFtpEvent) event);
		}
	}

	private void actionPerformedDirectory(DirectoryFtpEvent direvent) {
		if ("PRE".equals(direvent.getCommand())) {
			SiteBot irc = getSiteBot();
			LinkedRemoteFileInterface dir = direvent.getDirectory();
            	String sec = getGlobalContext().getSectionManager().lookup(dir.getPath()).getName();
            	String rotzcrapmist = dir.getPath();
            	SFVFile sfvfile = null;
            	String sfvcrap = null;
            	String nfofile = null;
            	String m3ufile = null;
            	String jpgfile = null;
            	int sfv = 0; 
            	int nfo = 0;
            	int m3u = 0;
            	int jpg = 0;
            	int totalfiles = 0;
            	long totalbytes = 0;
            	long nfobytes = 0;
      		
            	for (LinkedRemoteFileInterface aFile : LinkedRemoteFileUtils.getAllFiles(dir)) {
				try {
					if (aFile.getName().toLowerCase().endsWith(".sfv") && (!aFile.getParentFile().getName().toLowerCase().startsWith("sample") && !aFile.getParentFile().getName().toLowerCase().startsWith("sub"))) {
						try { 
					      	sfvfile = aFile.getSFVFile();
					      	totalfiles += sfvfile.size();
					      	totalbytes += sfvfile.getTotalBytes();                       
					    	} catch (Exception e) {
					     		continue;
					    	}
				     		sfv++;
					    	sfvcrap = aFile.getName();
					    	irc.say(channel ,"!sitesfv " + direvent.getDirectory().getName() + " " + rotzcrapmist + " " + sfvcrap);
					} else if (aFile.getName().toLowerCase().endsWith(".nfo")) {
					    	nfo++;
					    	nfofile = aFile.getName();
					    	nfobytes =+ aFile.length();
					    	irc.say(channel ,"!sitenfo " + direvent.getDirectory().getName() + " " + rotzcrapmist + " " + nfofile);
					} else if (aFile.getName().toLowerCase().endsWith(".m3u")) {
					    	m3u++;
					    	m3ufile = aFile.getName();
					    	irc.say(channel ,"!sitem3u " + direvent.getDirectory().getName() + " " + rotzcrapmist + " " + m3ufile);
					} else if (aFile.getName().toLowerCase().endsWith(".jpg")) {
					    	jpg++;
					    	jpgfile = aFile.getName();
					    	irc.say(channel ,"!sitejpg " + direvent.getDirectory().getName() + " " + rotzcrapmist + " " + jpgfile);
					}
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
            	}
            	if (sfv != 0) {
            		irc.say(channel ,"!sitepre " + direvent.getDirectory().getName() + " " + sec + " " + totalfiles + " " + PREFORMAT.format(totalbytes / 1048576.0));
            	} else {
            		if (nfo == 0) {
            			irc.say(channel ,"!sitepre " + direvent.getDirectory().getName() + " " + sec + " " + dir.getFiles().size() + " " + PREFORMAT.format(dir.dirSize() / 1048576.0));
            		} else {
            			irc.say(channel ,"!sitepre " + direvent.getDirectory().getName() + " " + sec + " " + (dir.getFiles().size()-nfo) + " " + PREFORMAT.format((dir.dirSize()-nfobytes) / 1048576.0));
            		}
            	}
        	} else if ("STOR".equals(direvent.getCommand())) {
           		 actionPerformedDirectorySTOR((TransferEvent) direvent);
        	}	
	}

	private void actionPerformedDirectorySTOR(TransferEvent direvent)  {
		SiteBot irc = getSiteBot();
		try {
			LinkedRemoteFile dir = direvent.getDirectory().getParentFile();
			if (dir.getPath().toUpperCase().contains("PRE")) return;
			if (direvent.getDirectory().getName().toLowerCase().endsWith(".nfo")) {
        			LinkedRemoteFileInterface file = direvent.getDirectory();
        			irc.say(channel ,"!sitenfo " + dir.getName() + " " + dir.getPath() + " " + file.getName());
			}
        		if (direvent.getDirectory().getName().toLowerCase().endsWith(".m3u")) {
        			LinkedRemoteFileInterface file = direvent.getDirectory();
        			irc.say(channel ,"!sitem3u " + dir.getName() + " " + dir.getPath() + " " + file.getName());
        		}
        		if (direvent.getDirectory().getName().toLowerCase().endsWith(".jpg")) {
        			LinkedRemoteFileInterface file = direvent.getDirectory();
        			if (dir.getName().length() < 10) {
   					irc.say(channel ,"!sitejpg " + dir.getParentFile().getName() + " " + dir.getPath() + " " + file.getName());
   				} else {
   					irc.say(channel ,"!sitejpg " + dir.getName() + " " + dir.getPath() + " " + file.getName());       			
   				}
			}
        		if (direvent.getDirectory().getName().toLowerCase().endsWith(".sfv")) {
        			LinkedRemoteFileInterface file = direvent.getDirectory();
       			if (dir.getName().length() < 10) {
       				irc.say(channel ,"!sitesfv " + dir.getParentFile().getName() + " " + dir.getPath() + " " + file.getName());
       			} else {
       				irc.say(channel ,"!sitesfv " + dir.getName() + " " + dir.getPath() + " " + file.getName());       			
       			}
			}
            	SFVFile sfvfile;
            	try {sfvfile = dir.lookupSFVFile();} catch (Exception ex) {return;}
            	if (!sfvfile.hasFile(direvent.getDirectory().getName())) return;
            	SFVStatus sfvstatus = sfvfile.getStatus();
        		if (sfvstatus.isFinished()) {
       			if (dir.getName().length() < 10) return;
        			irc.say(channel , "!siteinfo " + dir.getName() + " " + Integer.toString(sfvfile.size()) + " " + PREFORMAT.format(sfvfile.getTotalBytes() / 1048576.0));
        		}
		} catch (FileNotFoundException e) {
		}
	}

    	private SiteBot getSiteBot() {
    		SiteBot irc = null;
    		try {
    			irc = (SiteBot) getGlobalContext().getFtpListener(SiteBot.class);
    		} catch (ObjectNotFoundException e) {
    			e.printStackTrace();
    		}  
    		return irc;
    	}
    
	public void unload() {
	}
}