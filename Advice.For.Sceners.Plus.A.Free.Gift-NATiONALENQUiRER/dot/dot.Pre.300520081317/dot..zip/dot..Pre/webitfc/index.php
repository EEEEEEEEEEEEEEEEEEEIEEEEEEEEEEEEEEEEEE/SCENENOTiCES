<?php
## This is the web interface for the prebot
## If i can configure sudo properly i might be able to get so much more working

?>