#!/bin/sh
sysoplog="/glftpd/ftp-data/logs/sysop.log"
scanlines=100000
iptempfile="/glftpd/ftp-data/logs/iptransfer.log"

echo "-showip- / tested with glftpd 1.32 only"
echo "please wait... analyzing $scanlines lines"
tail -n "$scanlines" "$sysoplog" | grep attempt | cut -b 37- | sort | uniq | awk '{print $8}' | sort >"$iptempfile"
ipcount=$(cat $iptempfile | wc -l)
echo "$ipcount IPs written to $iptempfile"
